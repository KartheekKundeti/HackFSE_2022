import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placebid',
  templateUrl: './placebid.component.html',
  styleUrls: ['./placebid.component.css']
})
export class PlacebidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
